### main python script


from genImages import gitGenTempImages
from genVideo import genVideo


def main():

    gitGenTempImages()
    genVideo()


if __name__ == "__main__":
    main()
